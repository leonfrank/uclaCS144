The topUsers.scala both used spark rdd and dataframe. The output is splitted into multiple rdds.
