

    

    val lines=sc.textFile("twitter.edges")
    val users=lines.map(_.split(":")).flatMap{case Array(id, following)=>following.split(",").map(part =>(part.trim, 1))}
    val followcount=users.reduceByKey(_+_).filter(_._2>1000).sortBy(_._2, false)
    followcount.saveAsTextFile("output")

System.exit(0)
