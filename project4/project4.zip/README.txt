For the search page I chose k (number of results per page) to be 10. Hidden input fields allow the page to keep track of state and return results with different offsets.

Sites referenced:
http://www.codejava.net/java-ee/servlet/handling-html-form-data-with-java-servlet
https://www.tutorialspoint.com/java/java_strings.htm
